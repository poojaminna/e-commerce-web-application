INSERT INTO productrating (pid, username, rating)
VALUES (101, 'john_doe@gmail.com', 4.5),
       (101, 'jane_doe@gmail.com', 4.0),
       (102, 'john_doe@gmail.com', 4.8),
       (102, 'jane_doe@gmail.com', 4.2),
       (103, 'john_doe@gmail.com', 3.9),
       (103, 'jane_doe@gmail.com', 4.1);
