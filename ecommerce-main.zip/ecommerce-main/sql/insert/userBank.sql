INSERT INTO userbank (accountnumber, username)
VALUES (1001, 'john_doe@gmail.com'),
       (1002, 'jane_doe@gmail.com'),
       (1003, 'jack_smith@gmail.com'),
       (1004, 'jill_johnson@gmail.com');
