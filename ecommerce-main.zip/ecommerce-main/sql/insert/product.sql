INSERT INTO product (pid, pname, pdesc, pcategory)
VALUES (101, 'Samsung Galaxy S21', 'A high-end smartphone from Samsung', 'ELECTRONICS'),
       (102, 'Apple MacBook Pro', 'A powerful laptop from Apple', 'ELECTRONICS'),
       (103, 'Nike Air Zoom Pegasus 38', 'Running shoes from Nike', 'FASHION');
