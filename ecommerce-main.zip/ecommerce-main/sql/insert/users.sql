INSERT INTO user(username, password, fname, lname, isadmin)
VALUES ('admin@gmail.com', 'admin', 'admin', 'admin', TRUE),
       ('badri@gmail.com', 'badri', 'badri', 'badri', FALSE),
       ('moksha@gmail.com', 'moksha', 'moksha', 'moksha', FALSE),
       ('john_doe@gmail.com', 'johndoe', 'john', 'doe', FALSE),
       ('jane_doe@gmail.com', 'janedoe', 'jane', 'doe', FALSE),
       ('jack_smith@gmail.com', 'jacksmith', 'jack', 'smit', FALSE),
       ('jill_johnson@gmail.com', 'jilljohnson', 'jill', 'johnson', FALSE);
