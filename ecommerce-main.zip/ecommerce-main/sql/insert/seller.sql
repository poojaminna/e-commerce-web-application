INSERT INTO seller (sid, sname, accountnumber)
VALUES (201, 'ABC Corp', 1006),
       (202, 'XYZ Inc', 1007),
       (203, 'PQR Ltd', 1008);
