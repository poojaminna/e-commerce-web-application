INSERT INTO payment (payid, paymentstatus, userbankaccount)
VALUES (1, 'SUCCESS', 1001),
       (2, 'PENDING', 1002),
       (3, 'FAILED', 1003);
