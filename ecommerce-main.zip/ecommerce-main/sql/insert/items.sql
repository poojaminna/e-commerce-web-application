INSERT INTO items (price, quantity, pid, oid, sid)
VALUES (10.99, 2, 101, 1, 201),
       (8.49, 1, 102, 1, 202),
       (12.99, 3, 103, 2, 203);
