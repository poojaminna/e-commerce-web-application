INSERT INTO `Order` (oid, status, timestamp, username, aid, payid)
VALUES (1, 'PLACED', '2022-12-25 10:30:00', 'john_doe@gmail.com', 101, 1),
       (2, 'SHIPPED', '2022-12-26 11:45:00', 'jane_doe@gmail.com', 201, 2),
       (3, 'DELIVERED', '2022-12-27 12:15:00', 'jack_smith@gmail.com', 301, 3);
