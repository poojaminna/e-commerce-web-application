INSERT INTO inventory (price, quantity, discount, pid, sid)
VALUES (10.99, 100, 0.05, 101, 201),
       (8.49, 50, 0.02, 102, 202),
       (12.99, 200, 0.1, 103, 203);
