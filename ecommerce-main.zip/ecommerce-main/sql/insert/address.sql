INSERT INTO address (aid, line1, line2, city, state, zip, username)
VALUES (101, '123 Main St', 'Apt 2', 'Los Angeles', 'CA', '90001', 'john_doe@gmail.com'),
       (201, '456 Elm St', '', 'San Francisco', 'CA', '94109', 'jane_doe@gmail.com'),
       (301, '789 Oak Ave', '', 'New York', 'NY', '10001', 'jack_smith@gmail.com'),
       (401, '555 Pine St', '', 'Seattle', 'WA', '98101', 'jill_johnson@gmail.com');
