INSERT INTO BankAccount (accountnumber, branchcode, bank, routingnumber)
VALUES (1001, 'BR001', 'Bank A', '111000025'),
       (1002, 'BR002', 'Bank B', '222000025'),
       (1003, 'BR003', 'Bank C', '333000025'),
       (1004, 'BR004', 'Bank D', '444000025'),
       (1005, 'BR005', 'Bank E', '555000025'),
       (1006, 'BR003', 'Bank C', '333000025'),
       (1007, 'BR004', 'Bank D', '444000025'),
       (1008, 'BR005', 'Bank E', '555000025');
