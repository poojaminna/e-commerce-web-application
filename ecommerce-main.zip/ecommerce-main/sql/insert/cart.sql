INSERT INTO cart (quantity, pid, sid, username)
VALUES (2, 101, 201, 'john_doe@gmail.com'),
       (1, 102, 202, 'john_doe@gmail.com'),
       (3, 103, 203, 'jack_smith@gmail.com');
