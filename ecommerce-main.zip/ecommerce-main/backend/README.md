# Backend

## Installation

`npm install`

## Run

`npm start`
